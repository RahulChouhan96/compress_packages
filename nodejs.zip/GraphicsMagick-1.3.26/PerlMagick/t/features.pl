# Configuration-specific test suite definitions.
#

# Create a Perl list containing feature names
@MAGICK_FEATURES=qw();
